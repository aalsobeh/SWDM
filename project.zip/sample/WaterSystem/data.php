<?php

include 'conn.php';

date_default_timezone_set("Asia/Amman");
if(isset($_GET['lph']) && isset($_GET['user']) && isset($_GET['sector'])){
	$date = date('yy-m-d');
	$time = date('H:i:s');
	$litters = $_GET['lph'];
	$username = $_GET['user'];
	$sector = $_GET['sector'];
	$sql = "INSERT INTO data VALUES('".$litters."' , '".$date."' ,'".$time."' ,'".$username."','".$sector."')";
	if (mysqli_query($conn, $sql)) {
	    echo "New record created successfully";
	} else {
	    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	mysqli_close($conn);
}



//12/01/2020 11:20
/*
$d = date_create("12/01/2020 11:20");
$s = date_create("12/01/2020 14:30");
$diff = date_diff($s,$d);
echo $diff->format("%y %m %d %h %m %s");
*/
?>