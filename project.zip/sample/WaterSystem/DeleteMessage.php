<?php
include 'conn.php';

if(isset($_POST['messageID'])){
	$messageID = $_POST['messageID'];
	$sql = "DELETE FROM messages WHERE id={$messageID}";

	if (mysqli_query($conn, $sql)) {
	    echo '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
                        Message Deleted Successfully!
                   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                   </button>
               </div>';
	} else {
	    echo '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                There\'s a Problem 
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
           </button>
       </div>';
	}

	mysqli_close($conn);
}

?>

