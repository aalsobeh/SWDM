<?php
/*Include the library*/
require_once "conn.php";

/* 
    Least Squares : gives the predicted value which not in my range . 
    Using Average is The Best Way
*/

/* Handle Query*/
$LiterCost = 0.009;
if(isset($_POST['search'])){
    $queryResult = '<table class="table table-borderless table-striped table-earning"><thead><tr><th>User</th><th>Period</th><th>Liters/Hours</th><th>Cost/Hours</th></tr></thead><tbody>';
    $Sname   = $_POST['qname'];


    $FSday   = $_POST['fday'];
    $FSmonth = $_POST['fmonth'];
    $FSyear  = $_POST['fyear'];

    $TSday   = $_POST['tday'];
    $TSmonth = $_POST['tmonth'];
    $TSyear  = $_POST['tyear'];

    $FromDate = $FSyear . "-" . $FSmonth . "-" . $FSday;
    $ToDate = $TSyear . "-" . $TSmonth . "-" . $TSday;


    $DiffFrom = $FSyear . "-" . ($FSmonth-($TSmonth-$FSmonth)) . "-" . $FSday;


    //echo $DiffFrom . ' to ' . $FromDate;
    $sql = "SELECT user , AVG(litters) AS 'avg' FROM data WHERE user='".$Sname."' and date BETWEEN '".$DiffFrom ."' AND '".$FromDate."'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            if ($row['avg'] != ""){
                //$queryResult .= $row['avg'] . "  :  " . $row['avg']*0.009 . " Per / Hours<br>";
                $queryResult .= "<tr><td>".$row['user']."</td><td>".date('d-m-Y',strtotime($FromDate)) . " to " . date('d-m-Y',strtotime($ToDate)) ."</td><td>".$row['avg']."</td><td>".$row['avg']*$LiterCost."</td></tr>";
            }
        }
    }

    if($Sname == ""){
            $sql = "SELECT user , AVG(litters) AS 'avg' FROM data WHERE date BETWEEN '".$DiffFrom ."' AND '".$FromDate."' GROUP BY user";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    if ($row['avg'] != ""){

                        $queryResult .= "<tr><td>".$row['user']."</td><td>".date('d-m-Y',strtotime($FromDate)) . " to " . date('d-m-Y',strtotime($ToDate)) ."</td><td>".$row['avg']."</td><td>".$row['avg']*$LiterCost."</td></tr>";
                    }
                }
            }
    }

$queryResult .= '</tbody></table><br>';
echo $queryResult;
}

?>