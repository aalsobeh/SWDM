<?php
$conn = mysqli_connect("localhost","root","password","project");
if(!$conn){
	die("There's Problem ". mysqli_connect_error());
}
?>