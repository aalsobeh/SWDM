<?php
include 'conn.php';
session_start();
if(!isset($_SESSION["username"])){
    header("Location: login.php");
}

$role = $_SESSION['role'];
if($role == 0){
    header("Location: home.php");
}


//Residential
$ResidentialTable = "";
$ResidentialTable = "<tr>";
$sql = "SELECT username FROM users WHERE username!='admin' AND sector='Residential'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $ResidentialTable .= "<td>".$row['username']."</td>"; 
        $ResidentialTable .= "<td>".date('d-m-Y')."</td>";
    }
}


$lastHour = date('H:00:00',strtotime('-1 hour'));
$now = date("Y-m-d");
$lph = "SELECT sum(litters) AS 'lph' FROM data WHERE time='{$lastHour}' AND date='{$now}' AND sector='Residential'";
$result = mysqli_query($conn, $lph);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $p = 3600 * ($row['lph']/7.5);
        $ResidentialTable .= "<td>".$p."</td>";
        $ResidentialTable .= "<td>".($row['lph']* 0.001)."</td>";
    }
}


$lastDay= date('Y-m-d',strtotime('-1 day'));
$lpd = "SELECT sum(litters) AS 'lpd' FROM data WHERE date='{$lastDay}' AND sector='Residential'";
$result = mysqli_query($conn, $lpd);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $ResidentialTable .= "<td>".($row['lpd']* 0.001)."</td>";
    }
}



$now = date('m');
$lpm = "SELECT sum(litters) AS 'lpm' FROM data WHERE date LIKE '2020-{$now}-%' AND sector='Residential'";
$result = mysqli_query($conn, $lpm);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $ResidentialTable .= "<td>".($row['lpm']* 0.001)."</td>";
    }
}



$year = date('yy');
$lpy = "SELECT sum(litters) AS 'lpy' FROM data WHERE date LIKE '{$year}-%-%' AND sector='Residential'";
$result = mysqli_query($conn, $lpy);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $ResidentialTable .= "<td>".($row['lpy']* 0.001)."</td>";
    }
}
$ResidentialTable .= "</tr>";


//IndustrialTable
$IndustrialTable = "";
$IndustrialTable = "<tr>";
$sql = "SELECT username FROM users WHERE username!='admin' AND sector='Industrial'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $IndustrialTable .= "<td>".$row['username']."</td>"; 
        $IndustrialTable .= "<td>".date('d-m-Y')."</td>";
    }
}


$now = date('Y-m-d');
$lastHour = date('H:00:00',strtotime('-1 hour'));
$lph = "SELECT sum(litters) AS 'lph' FROM data WHERE date='{$now}' AND time='{$lastHour}' AND sector='Industrial'";
$result = mysqli_query($conn, $lph);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $p = 3600 * ($row['lph']/7.5);
        $IndustrialTable .= "<td>".$p."</td>";
        $IndustrialTable .= "<td>".$row['lph']."</td>";
    }
}


$now = date('Y-m-d');
$lastDay= date('Y-m-d',strtotime('-1 day'));
$lpd = "SELECT sum(litters) AS 'lpd' FROM data WHERE date='{$lastDay}' AND sector='Industrial'";
$result = mysqli_query($conn, $lpd);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $IndustrialTable .= "<td>".$row['lpd']."</td>";
    }
}


$now = date('m');
$lpm = "SELECT sum(litters) AS 'lpm' FROM data WHERE date LIKE '2020-{$now}-%' AND sector='Industrial'";
$result = mysqli_query($conn, $lpm);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $IndustrialTable .= "<td>".$row['lpm']."</td>";
    }
}


$year = date('Y');
$lpy = "SELECT sum(litters) AS 'lpy' FROM data WHERE date LIKE '{$year}-%-%' AND sector='Industrial'";
$result = mysqli_query($conn, $lpy);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $IndustrialTable .= "<td>".$row['lpy']."</td>";
    }
}
$IndustrialTable .= "</tr>";


//AgricultureTable
$AgricultureTable = "";
$AgricultureTable = "<tr>";
$sql = "SELECT username FROM users WHERE username!='admin' AND sector='Agriculture'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $AgricultureTable .= "<td>".$row['username']."</td>"; 
        $AgricultureTable .= "<td>".date('d-m-yy')."</td>";
    }
}
$now = date('Y-m-d');
$lastHour = date('H:00:00',strtotime('-1 hour'));
$lph = "SELECT sum(litters) AS 'lph' FROM data WHERE date='{$now}' AND time='{$lastHour}' AND sector='Agriculture'";
$result = mysqli_query($conn, $lph);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $p = 3600 * ($row['lph']/7.5);
        $AgricultureTable .= "<td>".$p."</td>";
        $AgricultureTable .= "<td>".$row['lph']."</td>";
    }
}
$now = date('Y-m-d');
$lastDay= date('Y-m-d',strtotime('-1 day'));
$lpd = "SELECT sum(litters) AS 'lpd' FROM data WHERE date='{$lastDay}' AND sector='Agriculture'";
$result = mysqli_query($conn, $lpd);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $AgricultureTable .= "<td>".$row['lpd']."</td>";
    }
}
$now = date('m');
$lpm = "SELECT sum(litters) AS 'lpm' FROM data WHERE date LIKE '2020-{$now}-%' AND sector='Agriculture'";
$result = mysqli_query($conn, $lpm);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $AgricultureTable .= "<td>".$row['lpm']."</td>";
    }
}
$year = date('Y');
$lpy = "SELECT sum(litters) AS 'lpy' FROM data WHERE date LIKE '{$year}-%-%' AND sector='Agriculture'";
$result = mysqli_query($conn, $lpy);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $AgricultureTable .= "<td>".$row['lpy']."</td>";
    }
}
$AgricultureTable .= "</tr>";



?>