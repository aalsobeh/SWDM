<?php
/*Include the library*/
session_start();
require_once "php-kmeans/src/KMeans/Space.php";
require_once "php-kmeans/src/KMeans/Point.php";
require_once "php-kmeans/src/KMeans/Cluster.php";
require_once "conn.php";

$CurrentUser = $_SESSION['username'];

/* Retrive Total Litter For Current User */
$Total = "SELECT sum(litters) AS 'Total' FROM data WHERE user='{$CurrentUser}'";

$result = mysqli_query($conn, $Total);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
       $Total = $row['Total']; 
    }
}

/* Getting Current Week */
$SeasonUsage = array();
$CurrentWeek = date("Y-m-d");


/* Retrive Total Litters Last Week */
$start = strtotime("2020-03-01");//strtotime(date("Y-m-d",strtotime('-3 month')));
$end = strtotime("2020-06-01");//strtotime(date("Y-m-d"));
while($start < $end){
    $time = date('Y-m-%', $start);
    //echo $time ,PHP_EOL;
    $UsagePerWeek = "SELECT sum(litters) AS 'LittersPerMonth' FROM data WHERE user='{$CurrentUser}' AND date LIKE '{$time}'";
    $result = mysqli_query($conn, $UsagePerWeek);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)){
            $LitterCost = 0.005;
            $new = array_push($SeasonUsage,array(   $row['LittersPerMonth']   ,  ($row['LittersPerMonth']*$LitterCost)  ));
        }
    }
    $start = strtotime("+1 month", $start);
}
//print_r($SeasonUsage);
/* Handle Points For K-Means Cluster Points ( Litters/Month , Cost/Month ) */
$points = $SeasonUsage;
$space = new KMeans\Space(2);

foreach ($points as $point){
    $space->addPoint($point);
}

$clusters = $space->solve(2);

$data = array();
foreach ($clusters as $i => $cluster){
    //printf("Cluster %d [%d,%d]: %d points<br>", $i, $cluster[0], $cluster[1], count($cluster));
    array_push($data,array($i, $cluster[0], $cluster[1], count($cluster)));
}

/* Get Abnormal Data ( Litters , Cost ) All Per Week */
$abnoramlLitters = max($data[0][1],$data[1][1]);
$abnoramlCost = max($data[0][2],$data[1][2]);

//echo $abnoramlLitters . "  " . $abnoramlCost , PHP_EOL;

$noramlLitters = min($data[0][1],$data[1][1]);
$noramlCost = min($data[0][2],$data[1][2]);

//echo $noramlLitters . "  " . $noramlCost , PHP_EOL;


$TotalLittersLastThreeMonths = 0;
for($month=0;$month<3;$month++){
    //echo $SeasonUsage[$month][0] , PHP_EOL ;
    $TotalLittersLastThreeMonths += $SeasonUsage[$month][0];
}

//echo sum($SeasonUsage);
//print_r($SeasonUsage);
/* Predict for Next Week */
$PredictedLittersNextSeason = $TotalLittersLastThreeMonths;
$TotalCostForNextSeason = round($PredictedLittersNextSeason*0.005);

$NextThreeMonths = date("d-m-Y" , strtotime("+3 month"));
$PredictNextMonth = '<div class="alert alert-success alert-dismissible fade show" role="alert">Predicted Usage For Next 3 Months From <strong>'.date("d-m-Y").'</strong> To <strong>'.$NextThreeMonths.'</strong> Will Be <strong>'.round($PredictedLittersNextSeason*0.001).'</strong> M<sup>3</sup> With Total Cost <strong>'.$TotalCostForNextSeason.'</strong> JOD<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';


/* Get The Abnormal Data and Normal Data */
$Last3Months = date('Y-m-d',strtotime('+3 month'));
$UsagePerWeek = "SELECT sum(litters) AS 'LittersPerWeek' FROM data WHERE user='".$CurrentUser."' AND date BETWEEN '".$Last3Months."' AND '".$CurrentWeek."'";
$result = mysqli_query($conn, $UsagePerWeek);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $x2 = $row['LittersPerWeek'];
        $y2 = ($row['LittersPerWeek'] * $LitterCost);
    }
}

$x1 = $abnoramlLitters;
$y1 = $abnoramlCost;
$M1 = sqrt(pow($x1-$x2 , 2.0) + pow($y1 - $y2 , 2.0));

$x1 = $noramlLitters;
$y1 = $noramlCost;
$M2 = sqrt(pow($x1-$x2 , 2.0) + pow($y1 - $y2 , 2.0));

$Warning = "";
if($M1 <= $M2){
    $Warning = '<div class="container-fluid"><div class="col-lg-12"><div class="alert alert-warning alert-dismissible fade show" role="alert">You Have <strong>Abnormal Usage </strong>Of Water <b>'. $abnoramlLitters .'</b> Litters With Total Cost Around <b>'.$abnoramlCost.'</b> JOD<button type="button" class="close" data-dismiss="alert" aria-label="Close">  <span aria-hidden="true">&times;</span></button></div></div></div>';
}

?>