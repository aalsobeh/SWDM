<?php
include 'conn.php';
include 'analysis.php';

session_start();
$CurrentUser = "";

if(!isset($_SESSION["username"])){
    header("Location: login.php");
}else{
    $CurrentUser = $_SESSION["username"];
}


/* Message Handler */
$messages = "";
$sql = "SELECT * FROM messages WHERE user='$CurrentUser'";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result) > 0){
    while ( $row = mysqli_fetch_assoc($result)) {
        $messages .= '<tr class="tr-shadow">
                    <td width="10%"><span class="block-email">admin</span></td>
                    <td class="desc">'.$row['message'].'</td>
                    <td width="10%">
                        <div class="table-data-feature">
                            <span class="delete" id="del_'.$row['id'].'" style="font-size: 20px;color:red;"><i class="zmdi zmdi-delete"></i></span>
                        </div>
                    </td>
                </tr><tr class="spacer"></tr>';
    }
}



/* Filling The Chart */
$Total = "SELECT sum(litters) AS 'Total' FROM data WHERE user='".$CurrentUser."'";
$result = mysqli_query($conn, $Total);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
       $Total = $row['Total']; 
    }
}

$MonthArray = array();

/* GET Months 1-12 */
for($i=1;$i<=12;$i++){
    if($i<10){$i = "0".$i;}
    $UsagePerMonth = "SELECT sum(litters) AS 'LittersPerMonth' FROM data WHERE user='".$CurrentUser."' AND date LIKE '2020-".$i."-%'";
    $result = mysqli_query($conn, $UsagePerMonth);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $LitterCost = 0.005;
            $new = array_push($MonthArray,($row['LittersPerMonth']*$LitterCost));
        }
    }
}


$UserData = array(
    array("label"=> "January", "y"=> $MonthArray[0]),
    array("label"=> "February", "y"=> $MonthArray[1]),
    array("label"=> "March", "y"=> $MonthArray[2]),
    array("label"=> "April", "y"=> $MonthArray[3]),
    array("label"=> "May", "y"=> $MonthArray[4]),
    array("label"=> "June", "y"=> $MonthArray[5]),
    array("label"=> "July", "y"=> $MonthArray[6]),
    array("label"=> "August", "y"=> $MonthArray[7]),
    array("label"=> "September", "y"=> $MonthArray[8]),
    array("label"=> "October", "y"=> $MonthArray[9]),
    array("label"=> "November", "y"=> $MonthArray[10]),
    array("label"=> "December", "y"=> $MonthArray[11])
);


$content = "";
for($i=1;$i<=12;$i++){

    if ( $i < 10 ) {
        $i = "0".$i;
    }

    $monthNum = $i;
    $monthName = date("F", mktime(0, 0, 0, $monthNum, 10));
    $content .= "<tr>";
    $content .= "<td>".$monthName."</td>";

    $ThisMonth = $monthNum;
    $PulsesMonth = "SELECT sum(litters) AS 'pulses' FROM data WHERE date LIKE '%-".$ThisMonth."-%' AND user='".$CurrentUser."'";
    $result = mysqli_query($conn, $PulsesMonth);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $p = 3600 * ($row['pulses']/7.5);
            $content .= "<td>".$p."</td>";
            
        }
    }

    $ThisMonth = $monthNum;
    $lpm = "SELECT sum(litters) AS 'lpm' FROM data WHERE date LIKE '%-".$ThisMonth."-%' AND user='".$CurrentUser."'";
    $result = mysqli_query($conn, $lpm);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $LittersPerMonth = $row['lpm'];
            $content .= "<td>".($row['lpm'] * 0.001)."</td>";
        }
    }



    $Sector = "SELECT sector  FROM data WHERE user='".$CurrentUser."' LIMIT 1";
    $result = mysqli_query($conn, $Sector);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $content .= "<td>".$row['sector']."</td>";
        }
    }

    $content .= "<td>".$LittersPerMonth*$LitterCost."</td>";
    $content .= "</tr>";
}

function filter($data){
        $error = 0;
        if(strpos($data,"--")!==false)
            $error = 1;
        if(strpos($data,"/*")!==false)
            $error = 1;
        if(strpos($data,"*/")!==false)
            $error = 1;
        if(strpos($data,"'")!==false)
            $error = 1;
        if(strpos($data,'"')!==false)
            $error = 1;
        if($error!=1){
            return $data;
        }
    }

/* Handle Problem Form */
$problemStatus = "";
if(isset($_POST['problem'])){
    $problemtext = filter($_POST['problemtext']);

    $sql = "INSERT INTO problems (user, problem) VALUES ('".$CurrentUser."', '".$problemtext."')";

    if(mysqli_query($conn, $sql)) {
        $problemStatus = '<div class="alert alert-success" role="alert">Problem Submited<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
    } else {
        $problemStatus = '<div class="alert alert-danger" role="alert">Somthing went wrong!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
    }

    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">
        <!-- PAGE CONTAINER-->
<div class="page-container--bgf7">
             <!-- HEADER DESKTOP-->
    <header class="header-desktop">
        <div class="section__content section__content">
            <div class="container-fluid">
                <div class="header-wrap">
                    <input class="au-input" id="myInput" type="text" name="name" placeholder="Search For Month" />
                    <div class="header-button">
                        <div class="account-wrap">
                            <div class="account-item clearfix js-item-menu">
                                <div class="image">
                                    <img src="images/icon/sample-pic.png" alt="" />
                                </div>
                                <div class="content">
                                    <a class="js-acc-btn" href="#"><?php echo $_SESSION["username"];?></a>
                                </div>
                                <div class="account-dropdown js-dropdown">
                                    <div class="info clearfix">
                                        <div class="image">
                                            <a href="#">
                                                <img src="images/icon/sample-pic.png" alt="John Doe" />
                                            </a>
                                        </div>
                                        <div class="content">
                                            <h5 class="name">
                                                <a href="#"><?php echo $_SESSION["username"];?></a>
                                            </h5>
                                            <span class="email"><?php echo $_SESSION["email"];?></span>
                                        </div>
                                    </div>
                                    <div class="account-dropdown__body">
                                        <div class="account-dropdown__item">
                                            <a href="/sample/WaterSystem/account.php">
                                                <i class="zmdi zmdi-account"></i>Account</a>
                                        </div>
                                         <div class="account-dropdown__footer">
                                            <a href="/sample/WaterSystem/logout.php">
                                                <i class="zmdi zmdi-power"></i>Logout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <?php echo $PredictNextMonth;?>
            <?php echo $Warning; ?>
            <div class="container-fluid">
                <!-- Waves Chart -->
                    <div class="col-lg-12">
                        <div class="au-card recent-report">
                            <div class="au-card-inner">
                                <h3 class="title-2">Digram</h3></br>
                                <div class="chart-info">
                                    <div class="chart-info__left">
                                        <div class="chart-note">
                                            <span class="dot dot--blue"></span>
                                            <span>Water Usage In <?php echo date("yy");?></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="chartContainer1" style="height: 370px; width: 100%;"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Sector One -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="title-1 m-b-25" id="table">Monthly Usage</h2>
                            <div class="table-responsive table--no-card m-b-40">
                                <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Pulses</th>
                                            <th>M3/Month</th>
                                            <th>Sector</th>
                                            <th>Cost/JOD</th>
                                        </tr>
                                    </thead>
                                    <tbody id="myTable">
                                        <?php echo $content;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
 
                <div class="row">
                    <div class="col-lg-12">
                        <div class="au-card chart-percent-card">
                            <div class="au-card-inner">

                                <div id="messagesStatus"></div>

                                <h3 class="title-2 tm-b-5">Messages</h3><br>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                <th width="10%">From</th>
                                                <th>Message</th>
                                                <th width="10%">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php echo $messages;?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>                

                <div class="row">
                    <div class="col-lg-12">
                        <div class="au-card chart-percent-card">
                            <div class="au-card-inner">
                                <h3 class="title-2 tm-b-5">Report a Problem</h3><br>
                                <div class="login-form">
                                    <form action="" method="post">
                                        <div class="form-group">
                                            <label>Problem</label>
                                            <textarea class="form-control" name="problemtext" id="validationTextarea" placeholder="Write a Problem" required></textarea>
                                        </div>
                                        <input class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name="problem" value="Submit">
                                    </form>
                                </div>
                                <?php echo $problemStatus;?>
                            </div>
                        </div>
                    </div>
                </div> 


                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2020 Water Flow.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
<!--
    <script>
    window.onload = function () {
        var chart = new CanvasJS.Chart("chartContainer1", {
            animationEnabled: true,  
            axisY: {
                valueFormatString: "#,,.",
                prefix: "Cost / JOD "
            },
            data: [{
                type: "splineArea",
                color: "rgba(54,158,173,.7)",
                markerSize: 5,
                dataPoints: <?php echo json_encode($UserData, JSON_NUMERIC_CHECK); ?>
            }]
            });
        chart.render();
    }
    </script>
-->


    <script>
    window.onload = function () {
     
    var chart = new CanvasJS.Chart("chartContainer1", {
        animationEnabled: true, 
        axisY: {
            valueFormatString: "#,,.",
            prefix: "Cost / JOD "
        },
        data: [{
            color: "rgba(0,0,0,.7)",
            type: "line",
            dataPoints: <?php echo json_encode($UserData, JSON_NUMERIC_CHECK); ?>
        }]
    });
    chart.render();
     
    }
    </script>

    <!-- Filter Table -->

     <script>
    $(document).ready(function(){
      $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function() {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
      });
    });
    </script> 


    <script src="vendor/jquery-3.2.1.min.js"></script>
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="vendor/slick/slick.min.js"></script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js"></script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    <script src="js/main.js"></script>

    <script>



            $(document).ready(function(){
                $('.delete').click(function(){
                   var el = this;
                   var id = this.id;
                   var splitid = id.split("_");
                   var deleteid = splitid[1];
                   DeleteMessage(deleteid);
                });
            });

        function DeleteMessage(deleteid){
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    location.reload(); 
                    document.getElementById("messagesStatus").innerHTML =  this.responseText;

               }
            };
            xhttp.open("POST", "DeleteMessage.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("messageID="+deleteid);
        }
    </script>
</body>

</html>
<!-- end document-->
