<?php
/* This File To Insert Dummy Data For Analysis And Demo */
/* , PHP_EOL : add endline ( if using terminal ).       */


//Include Database Connection File
include 'conn.php';

$user = 'farm1';
$sector = 'Agriculture';
$start = strtotime('2020-01-01 01:00:00');
$end = strtotime('2020-12-31 24:00:00');
while($start < $end)
{
	$random_liters = random_int(20, 40);
    $date = date('Y-m-d', $start);
    $time = date('H:i:s', $start);
    $sql = "INSERT INTO data  VALUES ('{$random_liters}', '{$date}' , '{$time}', '{$user}', '{$sector}')";
	if(mysqli_query($conn, $sql)){
		echo "Data Inserted", PHP_EOL;
	}else{
		echo "There's Problem " . mysqli_error($conn), PHP_EOL;
	}
    $start = strtotime("+1 hour", $start);
}
mysqli_close($conn);
?>