<?php
include 'conn.php';
session_start();
if(!isset($_SESSION["username"])){
    header("Location: login.php");
}

$role = $_SESSION['role'];
if($role == 0){
    header("Location: home.php");
}

include 'ZonesData.php';

$TotalRecords = 0;
$sql = "SELECT COUNT(*) AS 'Total' FROM data";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $TotalRecords = $row['Total']; 
    }
}





/* To Handle Pie Chart */
$Agriculture = 0;
$Residential = 0;
$Industrial = 0;
$SectrosUsage = "SELECT SUM(litters) AS 'Residential',(SELECT SUM(litters) FROM data WHERE sector='Agriculture') AS 'Agriculture'  ,(SELECT SUM(litters) FROM data WHERE sector='Industrial') AS 'Industrial' FROM data WHERE sector='Residential'";
$result = mysqli_query($conn, $SectrosUsage);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $Residential = $row['Residential'];
        $Agriculture = $row['Agriculture'];
        $Industrial = $row['Industrial'];
    }
}

/* Get Total Litters */      
$TotalLitters = $Residential + $Agriculture + $Industrial;

/* Fill Parcentage Into Chart */
$dataPoints = array(
    array("label"=> "Agriculture", "y"=> $Agriculture/$TotalLitters),
    array("label"=> "Industrial", "y"=> $Industrial/$TotalLitters),
    array("label"=> "Residential", "y"=> $Residential/$TotalLitters)
);


if(isset($_POST['problemId'])){
    $problemId = $_POST['problemId'];
    $sql = "DELETE FROM problems WHERE id={$problemId}";
    mysqli_query($conn, $sql);
    mysqli_close($conn);
    header("Refresh:0");
}


/* Handle Problem To show The Admin */
$ProblemTable = "";
$sql = "SELECT * FROM problems";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $ProblemTable = '<table style="overflow-y:scroll;height: 250px;display:block;" class="table table-borderless table-striped table-earning"><thead><tr><th>Status</th><th>User</th><th>Problem</th></tr></thead><tbody>';
    while($row = mysqli_fetch_assoc($result)) {
        $ProblemTable .= "<tr><td><form action='' method='POST'><input type='submit' class='btn btn-outline-success' value='Solved'><input type='hidden' name='problemId' value='".$row['id']."'></form></td><td>".$row['user']."</td><td width='100%'>".$row['problem']."</td></tr>";
    }
    $ProblemTable .= "</tbody></table>";
} else {
    $ProblemTable = "There's no problems";
}


mysqli_close($conn);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title Page-->
    <title>Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">
        <!-- PAGE CONTAINER-->
<div class="page-container--bgf7">
    <!-- HEADER DESKTOP-->
    <header class="header-desktop">
        <div class="section__content section__content">
            <div class="container-fluid">
                <div class="header-wrap">
                    <input class="au-input" id="myInput" type="text" placeholder="Search for users..." />
                    <div class="header-button">
                        <div class="account-wrap">
                            <div class="account-item clearfix js-item-menu">
                                <div class="image">
                                    <img src="images/icon/sample-pic.png" alt="" />
                                </div>
                                <div class="content">
                                    <a class="js-acc-btn" href="#"><?php echo $_SESSION["username"];?></a>
                                </div>
                                <div class="account-dropdown js-dropdown">
                                    <div class="info clearfix">
                                        <div class="image">
                                            <a href="#">
                                                <img src="images/icon/sample-pic.png" alt="" />
                                            </a>
                                        </div>
                                        <div class="content">
                                            <h5 class="name">
                                                <a href="#"><?php echo $_SESSION["username"];?></a>
                                            </h5>
                                            <span class="email"><?php echo $_SESSION["email"];?></span>
                                        </div>
                                    </div>
                                    <div class="account-dropdown__body">
                                        <div class="account-dropdown__item">
                                            <a href="/sample/WaterSystem/account.php">
                                                <i class="zmdi zmdi-account"></i>Account</a>
                                        </div>
                                         <div class="account-dropdown__footer">
                                            <a href="/sample/WaterSystem/logout.php">
                                                <i class="zmdi zmdi-power"></i>Logout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <!-- Send Notifecation To Users -->
                    <div class="col-lg-4" style="height: 300px;">
                        <div class="au-card chart-percent-card">
                            <div class="au-card-inner">
                                <h3 class="title-3 m-b-5">Messaging Service</h3>
                                <div class="form-group">
                                    <label class=" form-control-label">User</label>
                                    <input type="user" id="User" placeholder="User" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Message</label>    
                                    <textarea style="max-height: 150px;min-height: 150px" id="Message" rows="5" placeholder="Message..." class="form-control"></textarea>
                                </div>
                                <div class="form-group">  
                                    <input type="submit" onclick="MessageHandler();" value="Send" class="btn btn-primary">
                                    <div class="mt-3" id="MessageStatus"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                     <!-- Percent Chart -->
                    <div class="col-lg-8">
                        <div class="au-card chart-percent-card">
                            <div class="au-card-inner">
                                <h3 class="title-2 tm-b-5">recent reports</h3>
                                <div class="row no-gutters">
                                    <div class="col-xl-3">
                                        <div class="chart-note-wrap">
                                            <div class="chart-note mr-0 d-block">
                                                <span class="dot dot--blue"></span>
                                                <span>Agriculture</span>
                                            </div>
                                            <div class="chart-note mr-0 d-block">
                                                <span class="dot dot--red"></span>
                                                <span>Industrial</span>
                                            </div>
                                            <div class="chart-note mr-0 d-block">
                                                <span class="dot dot--green"></span>
                                                <span>Residential</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-9">
                                    <br>
                                    <div id="chartContainer2" style="height: 370px; width: 100%;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="au-card chart-percent-card">
                            <div class="au-card-inner">
                                <h3 class="title-2 tm-b-5">Problems</h3><br>
                                <?php echo $ProblemTable;?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Query Logging Table -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="au-card chart-percent-card">
                            <div class="au-card-inner">
                                <h3 class="title-2 tm-b-5">Query</h3><p>Total Records is <?php echo $TotalRecords;?></p><br>

                                  <div class="form-group" style="max-width: 25%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlInput1">User</label>
                                    <input type="text" class="form-control" id="qname" placeholder="name" name="sname">
                                  </div>
                                  <div style="max-width: 5%;float: left;padding:2.5% 2% 0 0;"><b>From</b></div>
                                  <div class="form-group" style="max-width: 30%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlSelect1">Day</label>
                                    <select class="form-control" id="fday" name="fsday">
                                      <option>1</option>
                                      <option>2</option>
                                      <option>3</option>
                                      <option>4</option>
                                      <option>5</option>
                                      <option>6</option>
                                      <option>7</option>
                                      <option>8</option>
                                      <option>9</option>
                                      <option>10</option>
                                      <option>11</option>
                                      <option>12</option>
                                      <option>13</option>
                                      <option>14</option>
                                      <option>15</option>
                                      <option>16</option>
                                      <option>17</option>
                                      <option>18</option>
                                      <option>19</option>
                                      <option>20</option>
                                      <option>21</option>
                                      <option>22</option>
                                      <option>23</option>
                                      <option>24</option>
                                      <option>25</option>
                                      <option>26</option>
                                      <option>27</option>
                                      <option>28</option>
                                      <option>29</option>
                                      <option>30</option>
                                      <option>31</option>
                                    </select>
                                  </div>

                                   <div class="form-group" style="max-width: 30%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlSelect1">Month</label>
                                    <select class="form-control" id="fmonth" name="fsmonth">
                                      <option>1</option>
                                      <option>2</option>
                                      <option>3</option>
                                      <option>4</option>
                                      <option>5</option>
                                      <option>6</option>
                                      <option>7</option>
                                      <option>8</option>
                                      <option>9</option>
                                      <option>10</option>
                                      <option>11</option>
                                      <option>12</option>
                                    </select>
                                  </div>

                                  <div class="form-group" style="max-width: 15%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlSelect1">Year</label>
                                    <input type="text" class="form-control" id="fyear" placeholder="year" name="fsyear">
                                  </div>
                                 <div style="max-width: 5%;float: left;padding:2.5% 1% 0 0;"><b>To</b></div>
                                <!-- To row-->
                                  <div class="form-group" style="max-width: 30%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlSelect1">Day</label>
                                    <select class="form-control" id="tday" name="tsday">
                                      <option>1</option>
                                      <option>2</option>
                                      <option>3</option>
                                      <option>4</option>
                                      <option>5</option>
                                      <option>6</option>
                                      <option>7</option>
                                      <option>8</option>
                                      <option>9</option>
                                      <option>10</option>
                                      <option>11</option>
                                      <option>12</option>
                                      <option>13</option>
                                      <option>14</option>
                                      <option>15</option>
                                      <option>16</option>
                                      <option>17</option>
                                      <option>18</option>
                                      <option>19</option>
                                      <option>20</option>
                                      <option>21</option>
                                      <option>22</option>
                                      <option>23</option>
                                      <option>24</option>
                                      <option>25</option>
                                      <option>26</option>
                                      <option>27</option>
                                      <option>28</option>
                                      <option>29</option>
                                      <option>30</option>
                                      <option>31</option>
                                    </select>
                                  </div>

                                   <div class="form-group" style="max-width: 30%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlSelect1">Month</label>
                                    <select class="form-control" id="tmonth" name="tsmonth">
                                      <option>1</option>
                                      <option>2</option>
                                      <option>3</option>
                                      <option>4</option>
                                      <option>5</option>
                                      <option>6</option>
                                      <option>7</option>
                                      <option>8</option>
                                      <option>9</option>
                                      <option>10</option>
                                      <option>11</option>
                                      <option>12</option>
                                    </select>
                                  </div>

                                  <div class="form-group" style="max-width: 15%;float: left;padding-right: 1%;">
                                    <label for="exampleFormControlSelect1">Year</label>
                                    <input type="text" class="form-control" id="tyear" placeholder="year" name="tsyear">
                                  </div>
                                  <div class="form-group" style="max-width: 30%;float: left;">
                                    <label for="exampleFormControlSelect1"></label>
                                    <input class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name="search" onclick="QueryHandler();" value="Search">
                                </div>
                                </div>
                            
                                <!-- Query Table -->
                                <div id="queryResult"></div>
                               <!--
                                   <div id="query" style="height: 370px; width: 100%;"></div>
                                -->
                                   
                               
                            </div>
                        </div>
                    </div>
                </div>

                    <!-- Sector One -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="title-1 m-b-25" id="table">Residential</h2>
                            <div class="table-responsive table--no-card m-b-40">
                                <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Date</th>
                                            <th>Pulses</th>
                                            <th>M<sup>3</sup>/Hour</th>
                                            <th>M<sup>3</sup>/Day</th>
                                            <th>M<sup>3</sup>/Month</th>
                                            <th>M<sup>3</sup>/Year</th>
                                        </tr>
                                    </thead>
                                    <tbody id="myTable1">
                                        <?php echo $ResidentialTable; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="title-1 m-b-25" id="table">Industrial</h2>
                            <div class="table-responsive table--no-card m-b-40">
                                <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Date</th>
                                            <th>Pulses</th>
                                            <th>M<sup>3</sup>/Hour</th>
                                            <th>M<sup>3</sup>/Day</th>
                                            <th>M<sup>3</sup>/Month</th>
                                            <th>M<sup>3</sup>/Year</th>
                                        </tr>
                                    </thead>
                                    <tbody id="myTable2">
                                       <?php echo $IndustrialTable;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="title-1 m-b-25" id="table">Agriculture</h2>
                            <div class="table-responsive table--no-card m-b-40">
                                <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Date</th>
                                            <th>Pulses</th>
                                            <th>M<sup>3</sup>/Hour</th>
                                            <th>M<sup>3</sup>/Day</th>
                                            <th>M<sup>3</sup>/Month</th>
                                            <th>M<sup>3</sup>/Year</th>
                                        </tr>
                                    </thead>
                                    <tbody id="myTable3">
                                        <?php echo $AgricultureTable;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!--</div>-->

                    <!-- footer -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2020 Water Flow.</p>
                                </div>
                            </div>
                        </div>
                    <!-- ./footer -->

                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>

    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>

    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js"></script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js"></script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
    <script>
    window.onload = function () {

    var percentChart = new CanvasJS.Chart("chartContainer2", {
        animationEnabled: true,
        exportEnabled: true,
        data: [{
            type: "pie",
            showInLegend: "true",
            legendText: "{label}",
            indexLabelFontSize: 16,
            indexLabel: "{label} - #percent%",
            yValueFormatString: "%#.##0",
            dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
        }]
    });
    percentChart.render();
    }
    </script>

    <script>
        $(document).ready(function(){
          $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable1 tr").filter(function() {
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
          });
        });
    </script> 

    <script>
        $(document).ready(function(){
          $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable2 tr").filter(function() {
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
          });
        });
    </script> 

    <script>
        $(document).ready(function(){
          $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable3 tr").filter(function() {
              $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
          });
        });
    </script> 


    <script>
        function MessageHandler() {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("MessageStatus").innerHTML = this.responseText;
                    //Clearing Input Feild.
                    document.getElementById("User").value = "";
                    document.getElementById("Message").value = "";
               }
            };
            var User = document.getElementById("User").value;
            var Message = document.getElementById("Message").value;
            xhttp.open("POST", "message.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("User="+User+"&Messages="+Message); 
        }


        function QueryHandler(){
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("queryResult").innerHTML = this.responseText;
               }
            };
            var user = document.getElementById("qname").value;
            var fday = document.getElementById("fday").value;
            var fmonth = document.getElementById("fmonth").value;
            var fyear = document.getElementById("fyear").value;
            var tday = document.getElementById("tday").value;
            var tmonth = document.getElementById("tmonth").value;
            var tyear = document.getElementById("tyear").value;
            console.log(user);console.log(fday);console.log(fmonth);console.log(fyear);console.log(tday);console.log(tmonth);console.log(tyear);
            xhttp.open("POST", "QueryAnalysis.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("qname="+user+"&fday="+fday+"&fmonth="+fmonth+"&fyear="+fyear+"&tday="+tday+"&tmonth="+tmonth+"&tyear="+tyear+"&search=Search");          
        }
    </script>

</body>

</html>
<!-- end document-->
