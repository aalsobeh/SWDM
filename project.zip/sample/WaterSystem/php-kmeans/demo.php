<?php

$conn = mysqli_connect("localhost","root","password","project");
if(!$conn){
	die("There's Problem ". mysqli_connect_error());
}
// include the library
require_once "src/KMeans/Space.php";
require_once "src/KMeans/Point.php";
require_once "src/KMeans/Cluster.php";

$CurrentUser = 'saif';

$Total = "SELECT sum(litters) AS 'Total' FROM data WHERE username='".$CurrentUser."'";
$result = mysqli_query($conn, $Total);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
       $Total = $row['Total']; 
    }
}

$MonthArray = array();
$CurrentMonth = '07';//date("m");

for($i=1;$i<=$CurrentMonth;$i++){
    if ( $i < 10 ) {
        $i = "0".$i;
    }
    $UsagePerMonth = "SELECT sum(litters) AS 'LittersPerMonth' FROM data WHERE username='".$CurrentUser."' AND date LIKE '%-".$i."-2020 %:%:%'";
    $result = mysqli_query($conn, $UsagePerMonth);
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)){
            $LitterCost = 0.05;
            $new = array_push($MonthArray,array($row['LittersPerMonth'],($row['LittersPerMonth']*$LitterCost)));
        }
    }
}


/*
$UsagePerMonth = "SELECT sum(litters) AS 'LittersPerMonth' FROM data WHERE username='".$CurrentUser."' AND date LIKE '%-".$$CurrentMonth."-2020 %:%:%'";
$result = mysqli_query($conn, $UsagePerMonth);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $LitterCost = 0.05;
        $new = array_push($MonthArray,array($row['LittersPerMonth'],($row['LittersPerMonth']*$LitterCost)));
    }
}
*/
//print_r($MonthArray[1][0]);

$points = array();
for($month=0;$month<$CurrentMonth;$month++){
	$new = array_push($points,array($MonthArray[$month][0],$MonthArray[$month][1]));
}

$space = new KMeans\Space(2);
foreach ($points as $point)
    $space->addPoint($point);

$clusters = $space->solve(2);
$data = array();
foreach ($clusters as $i => $cluster){
    array_push($data,array($i, $cluster[0], $cluster[1], count($cluster)));
}

$abnoramlLitters = max($data[0][1],$data[1][1]);
$abnoramlCost = max($data[0][2],$data[1][2]);

echo "Abnormal Litters: " . $abnoramlLitters . "\nAbnormal Costs: " . $abnoramlCost . "\n";