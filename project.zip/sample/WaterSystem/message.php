<?php
/* Send Messages To Users */ 
include 'conn.php';

$messageStatus='';

if(isset($_POST['Messages']) && isset($_POST['User'])){
	$user = $_POST['User'];
	$message = $_POST['Messages'];
	if($user == "" || $message == ""){
		$messageStatus = '<div class="sufee-alert alert with-close alert-warning alert-dismissible fade show">Should Fill All Input<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>';
	}else{
		$sql = "SELECT * FROM users WHERE username='{$user}'";
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) == 1) {
		    //Check User If Exist
			$sql = "INSERT INTO messages (user, message) VALUES ('{$user}', '{$message}')";
			if (mysqli_query($conn, $sql)) {
				$messageStatus = '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">Messages Sent Successfully<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>';
			} else {
			    $messageStatus = '<div class="sufee-alert alert with-close alert-warning alert-dismissible fade show">There\'s a Problem<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>';
			}
			mysqli_close($conn);

		} else {
			//User Not Exist
			$messageStatus = '<div class="sufee-alert alert with-close alert-warning alert-dismissible fade show">User Not Exist<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button></div>';
		}
	}
}

echo $messageStatus;
?>